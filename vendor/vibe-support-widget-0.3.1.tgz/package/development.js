const labels={queued:'I kö',running:'Arbetar',review:'Kontrollerad – väntar på publicering eller granskning',deploying:'Publicerar',published:'Publicerad',failed:'Behöver granskas',deploy_failed:'Publiceringen behöver granskas',interrupted:'Avbruten körning',cancelled:'Avbruten'};
const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
/** An app-specific owner session, obtained with explicit Cloud consent. */
export function developmentControls(root,cloud,app,{changed,locale='sv'}){
  const key=`vibe-support-owner:${cloud}:${app}`;let session=null,popup=null,state='',disposed=false,timer;
  try{session=JSON.parse(sessionStorage.getItem(key)??'null');if(session?.expires<=Date.now())session=null;}catch{}
  const box=document.createElement('section');box.className='developer-area';root.querySelector('form').before(box);
  const controls=document.createElement('div');controls.className='development-approval';root.querySelector('form .submit').before(controls);
  const jobs=document.createElement('section');jobs.className='development-jobs';root.querySelector('.status').after(jobs);
  const clear=()=>{session=null;try{sessionStorage.removeItem(key);}catch{}controls.replaceChildren();jobs.replaceChildren();};
  const request=async()=>{if(!session)return null;const r=await fetch(`${cloud}/api/development/widget`,{headers:{Authorization:`Bearer ${session.token}`},credentials:'omit',referrerPolicy:'no-referrer',signal:AbortSignal.timeout(10000)});if(!r.ok){if(r.status===401)clear();throw new Error('Utvecklaranslutningen behöver förnyas.');}return r.json();};
  function disconnected(){box.innerHTML='<details><summary>Utvecklarläge</summary><p class="hint">Är du appägare? Anslut ditt Vibe-konto för att godkänna ändringar direkt här.</p><button type="button" data-connect-owner>Anslut utvecklarkonto</button><p role="status" data-connect-status></p></details>';controls.replaceChildren();
    const link=root.querySelector('dialog>a');if(link){link.hidden=false;link.nextElementSibling.hidden=false;}const hint=root.querySelector('form>p.hint');if(hint)hint.hidden=false;
    box.querySelector('[data-connect-owner]').onclick=()=>{state=crypto.randomUUID();popup=window.open(`${cloud}/support?app=${encodeURIComponent(app)}&connect=1&state=${state}`,'vibe-support-owner','popup,width=540,height=760');box.querySelector('[data-connect-status]').textContent=popup?'Bekräfta anslutningen i fönstret som öppnades.':'Tillåt popupfönster för att ansluta kontot.';};
  }
  function show(data){
    const link=root.querySelector('dialog>a');if(link){link.hidden=true;link.nextElementSibling.hidden=true;}const hint=root.querySelector('form>p.hint');if(hint)hint.hidden=true;
    box.innerHTML='<div class="developer-connected"><span>Utvecklarläge · verifierad appägare</span><button type="button" data-disconnect-owner>Koppla från</button></div>';
    box.querySelector('[data-disconnect-owner]').onclick=()=>{clear();disconnected();changed();};
    if(!controls.childElementCount&&data.canImplement){controls.innerHTML=`<label class="approval-choice"><input type="checkbox" name="implement"><span><strong>${data.canPublish?'Godkänn implementation och publicering':'Godkänn implementation'}</strong><small>Agenten använder din beskrivning och bilagor. Extra instruktion är valfri.</small></span></label><details><summary>Extra instruktion (valfritt)</summary><textarea name="instruction" maxlength="4000" rows="2" placeholder="Till exempel vad som ska behållas eller hur resultatet ska fungera."></textarea></details>`;}
    if(!data.canImplement)controls.innerHTML='<p class="hint">Utvecklingskopplingen är pausad i Cloud.</p>';
    const active=data.presence&&Date.now()-data.presence.seen<120000;
    jobs.innerHTML=`<h3>Dina senaste uppdrag</h3><p class="hint">${active?'Körprocessen är ansluten.':'Körprocessen är inte ansluten just nu. Godkända uppdrag ligger kvar i kön.'}</p>${data.jobs.map(j=>`<article><strong>${escape(labels[j.status]??j.status)}</strong><p>${escape(j.message)}</p>${j.status==='published'?'<p class="hint">Ladda om sidan för att se ändringen.</p>':''}<a target="_blank" rel="noopener noreferrer" href="${cloud}/support?app=${encodeURIComponent(app)}&admin=1&ticket=${encodeURIComponent(j.ticket)}">Öppna ärendet ↗</a></article>`).join('')||'<p class="hint">Inga uppdrag ännu.</p>'}`;
  }
  async function refresh(){if(disposed)return null;if(!session){if(!box.querySelector('[data-connect-owner]'))disconnected();return null;}try{const data=await request();if(!disposed&&data)show(data);return data;}catch{if(!session)disconnected();return null;}}
  const receive=async e=>{if(e.origin!==cloud||e.source!==popup||e.data?.type!=='vibe-support-connected'||e.data.state!==state||typeof e.data.token!=='string'||!e.data.token.startsWith('vsw_'))return;session={token:e.data.token,expires:e.data.expires};try{sessionStorage.setItem(key,JSON.stringify(session));}catch{}popup?.close();popup=null;await refresh();changed();};window.addEventListener('message',receive);
  timer=setInterval(()=>{if(root.querySelector('dialog')?.open)void refresh();},10000);
  disconnected();return {refresh,authorization:()=>session?`Bearer ${session.token}`:null,clear(){clear();disconnected();},destroy(){disposed=true;clearInterval(timer);window.removeEventListener('message',receive);popup?.close();}};
}
