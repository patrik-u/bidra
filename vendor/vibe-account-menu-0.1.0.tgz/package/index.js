// Authentication stays in the host's SDK. This module stores no account data.
const text = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const messages = {
  sv: { login: 'Logga in', account: 'Kontomeny', profile: 'Profil och kontoinställningar', switch: 'Växla användare', logout: 'Logga ut från', remembered: 'Tidigare använda här', privacy: 'Konton som använts i den här webbläsaren på denna sajt.', provider: 'Konto via Vibe', identity: 'Identitet', busy: 'Ansluter…' },
  en: { login: 'Log in', account: 'Account menu', profile: 'Profile and account settings', switch: 'Switch account', logout: 'Log out of', remembered: 'Previously used here', privacy: 'Accounts used in this browser on this site.', provider: 'Account via Vibe', identity: 'Identity', busy: 'Connecting…' },
};
const paths = {
  user: '<path d="M20 21v-2a7 7 0 0 0-14 0v2"/><circle cx="13" cy="7" r="4"/>',
  switch: '<path d="m16 3 4 4-4 4M4 7h16M8 21l-4-4 4-4m12 4H4"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4m7 14 5-5-5-5M21 12H9"/>',
  bookmark: '<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
  settings: '<path d="M4 7h16M4 17h16M8 4v6m8 4v6"/>',
  external: '<path d="M15 3h6v6m0-6L10 14m-1-11H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4"/>',
  chevron: '<path d="m6 9 6 6 6-6"/>',
};
const icon = name => `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] ?? paths.user}</svg>`;
function safeUrl(value) {
  if (!value) return '';
  try { const url = new URL(value); return url.protocol === 'https:' || (url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname)) ? url.href : ''; } catch { return ''; }
}
function avatar(profile) {
  const image = profile.avatarDataUri;
  const initials = profile.displayName.trim().split(/\s+/).slice(0, 2).map(word => [...word][0] ?? '').join('').toLocaleUpperCase();
  // Only SDK profile raster data is accepted; arbitrary URLs cannot track a menu open.
  return `<span class="vibe-account-avatar" aria-hidden="true">${typeof image === 'string' && image.length < 800000 && /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(image) ? `<img src="${text(image)}" alt="" />` : `<span>${text(initials || '?')}</span>`}</span>`;
}
function identityCue(did) {
  let seed = 2166136261;
  for (const char of did) seed = Math.imul(seed ^ char.charCodeAt(0), 16777619) >>> 0;
  let cells = '';
  for (let y = 0; y < 5; y++) for (let x = 0; x < 3; x++) {
    if ((seed >>> (y * 3 + x)) & 1) { cells += `<rect x="${x}" y="${y}" width="1" height="1"/>`; if (x !== 2) cells += `<rect x="${4 - x}" y="${y}" width="1" height="1"/>`; }
  }
  return `<svg viewBox="-1 -1 7 7" width="22" height="22" aria-hidden="true" fill="hsl(${seed % 360} 45% 38%)">${cells}</svg>`;
}
function remembered(options) {
  const seen = new Set([options.profile?.rootDid]);
  return (options.remembered ?? []).filter(item => { if (!item.rootDid || seen.has(item.rootDid)) return false; seen.add(item.rootDid); return true; }).slice(0, 8);
}
export function accountMenuMarkup(options, id = 'vibe-account-panel') {
  const m = messages[options.locale] ?? messages.en;
  const profile = options.profile;
  const disabled = options.busy ? 'disabled' : '';
  if (!profile) return `<button type="button" class="vibe-account-login" data-account-login ${disabled}>${icon('user')}<span>${text(options.busy ? m.busy : m.login)}</span></button>`;
  const profileUrl = safeUrl(options.profileUrl);
  const previous = remembered(options);
  return `<button type="button" class="vibe-account-trigger ${options.compact ? 'vibe-account-compact' : ''}" data-account-trigger aria-haspopup="menu" aria-controls="${text(id)}" aria-expanded="false" aria-label="${text(m.account)}: ${text(profile.displayName)}">${avatar(profile)}<span class="vibe-account-trigger-copy"><strong>${text(profile.displayName)}</strong><small>@${text(profile.handle)}</small></span>${icon('chevron')}</button>
  <div class="vibe-account-panel" id="${text(id)}" role="menu" aria-label="${text(m.account)}" hidden>
    <div class="vibe-account-heading" role="presentation">${avatar(profile)}<div><strong>${text(profile.displayName)}</strong><span>@${text(profile.handle)}</span></div></div>
    <div class="vibe-account-identity" title="${text(profile.rootDid)}" role="presentation">${identityCue(profile.rootDid)}<span>${text(m.identity)} · ${text(profile.rootDid.length > 26 ? profile.rootDid.slice(0, 15) + '…' + profile.rootDid.slice(-7) : profile.rootDid)}</span></div>
    ${profileUrl ? `<a role="menuitem" class="vibe-account-item" data-account-key="profile" href="${text(profileUrl)}" target="_blank" rel="noopener noreferrer">${icon('user')}<span>${text(m.profile)}</span>${icon('external')}</a>` : ''}
    ${(options.actions ?? []).map((action, index) => { const href = safeUrl(action.href); return href ? `<a role="menuitem" class="vibe-account-item" data-account-key="action-${index}" href="${text(href)}" target="_blank" rel="noopener noreferrer">${icon(action.icon)}<span>${text(action.label)}</span></a>` : action.onSelect ? `<button type="button" role="menuitem" class="vibe-account-item" data-account-key="action-${index}" data-account-action="${index}" ${disabled}>${icon(action.icon)}<span>${text(action.label)}</span></button>` : ''; }).join('')}
    ${previous.length ? `<div class="vibe-account-section" role="presentation">${text(m.remembered)}</div>${previous.map((item, index) => `<button type="button" role="menuitem" class="vibe-account-item" data-account-key="remembered-${index}" data-account-remembered="${index}" ${disabled}>${avatar(item)}<span><strong>${text(item.displayName)}</strong><small>@${text(item.handle)}</small></span></button>`).join('')}<p class="vibe-account-hint" role="presentation">${text(m.privacy)}</p>` : ''}
    <div class="vibe-account-divider" role="separator"></div>
    <button type="button" role="menuitem" class="vibe-account-item" data-account-key="switch" data-account-switch ${disabled}>${icon('switch')}<span>${text(m.switch)}</span></button>
    <button type="button" role="menuitem" class="vibe-account-item" data-account-key="logout" data-account-logout ${disabled}>${icon('logout')}<span>${text(m.logout)} ${text(options.appName)}</span></button>
    ${options.notice ? `<p class="vibe-account-hint" role="status">${text(options.notice)}</p>` : ''}
    <div class="vibe-account-provider" role="presentation">${text(m.provider)}</div>
  </div>`;
}
let sequence = 0;
export function createAccountMenu(container, initial) {
  let options = initial, open = false, destroyed = false, invoking = false;
  const id = `vibe-account-${++sequence}`;
  const doc = container.ownerDocument, win = doc.defaultView;
  container.classList.add('vibe-account');
  const panel = () => container.querySelector('.vibe-account-panel');
  const trigger = () => container.querySelector('[data-account-trigger]');
  const items = () => [...container.querySelectorAll('[role="menuitem"]:not(:disabled)')];
  function position() {
    const el = panel(), button = trigger();
    if (!open || !el || !button) return;
    const box = button.getBoundingClientRect();
    const height = win.visualViewport?.height ?? win.innerHeight, width = win.visualViewport?.width ?? win.innerWidth;
    const below = height - box.bottom - 16, above = box.top - 16;
    const useAbove = options.placement === 'above' ? above >= Math.min(el.scrollHeight, 260) || above > below : below < Math.min(el.scrollHeight, 260) && above > below;
    el.style.maxHeight = `${Math.max(100, useAbove ? above : below)}px`;
    el.style.width = `${Math.min(310, width - 24)}px`;
    el.style.left = `${Math.max(12, Math.min(box.right - el.offsetWidth, width - el.offsetWidth - 12))}px`;
    el.style.top = `${useAbove ? Math.max(12, box.top - el.offsetHeight - 8) : box.bottom + 8}px`;
  }
  function setOpen(value, returnFocus = false) {
    open = Boolean(value && options.profile);
    const el = panel(); if (el) el.hidden = !open;
    trigger()?.setAttribute('aria-expanded', String(open));
    if (open) position(); else if (returnFocus) trigger()?.focus();
  }
  function render() {
    const focusedKey = container.contains(doc.activeElement) ? doc.activeElement?.getAttribute('data-account-key') : null;
    const focusedTrigger = doc.activeElement === trigger();
    container.innerHTML = accountMenuMarkup(options, id);
    container.querySelectorAll('.vibe-account-avatar img').forEach(img => img.addEventListener('error', () => { const span = doc.createElement('span'); span.textContent = '?'; img.replaceWith(span); }, { once: true }));
    setOpen(open);
    if (focusedKey && open) items().find(item => item.getAttribute('data-account-key') === focusedKey)?.focus();
    else if (focusedTrigger) trigger()?.focus();
  }
  function invoke(callback) {
    if (options.busy || invoking || !callback) return;
    setOpen(false, true); invoking = true;
    // Invoke synchronously inside the user gesture so popup authorization still works.
    try { Promise.resolve(callback()).catch(error => options.onError?.(error)).finally(() => { invoking = false; }); }
    catch (error) { invoking = false; options.onError?.(error); }
  }
  function click(event) {
    const target = event.target.closest('button, a'); if (!target || !container.contains(target)) return;
    if (target.hasAttribute('data-account-trigger')) { setOpen(!open); if (open) items()[0]?.focus(); }
    else if (target.hasAttribute('data-account-login')) invoke(options.onLogin);
    else if (target.hasAttribute('data-account-switch')) invoke(() => options.onSwitchAccount());
    else if (target.hasAttribute('data-account-logout')) invoke(options.onLogout);
    else if (target.hasAttribute('data-account-remembered')) { const account = remembered(options)[Number(target.dataset.accountRemembered)]; if (account) invoke(() => options.onSwitchAccount(account.handle)); }
    else if (target.hasAttribute('data-account-action')) invoke(options.actions?.[Number(target.dataset.accountAction)]?.onSelect);
    else if (target.tagName === 'A') setOpen(false);
  }
  function keydown(event) {
    if (event.key === 'Escape' && open) { event.preventDefault(); event.stopPropagation(); setOpen(false, true); return; }
    if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key) || !options.profile) return;
    event.preventDefault();
    const wasOpen = open; setOpen(true); const list = items(), index = list.indexOf(doc.activeElement);
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? list.length - 1 : event.key === 'ArrowDown' ? (!wasOpen ? 0 : (index + 1) % list.length) : (!wasOpen || index < 0 ? list.length - 1 : (index - 1 + list.length) % list.length);
    list[next]?.focus();
  }
  const outside = event => { if (!container.contains(event.target)) setOpen(false); };
  container.addEventListener('click', click); container.addEventListener('keydown', keydown);
  doc.addEventListener('pointerdown', outside); doc.addEventListener('focusin', outside);
  win.addEventListener('resize', position); win.addEventListener('scroll', position, true);
  win.visualViewport?.addEventListener('resize', position);
  render();
  return {
    open() { if (!destroyed) { setOpen(true); items()[0]?.focus(); } },
    update(next) { if (destroyed) return; if (next.profile?.rootDid !== options.profile?.rootDid) open = false; options = next; render(); },
    destroy() { destroyed = true; container.removeEventListener('click', click); container.removeEventListener('keydown', keydown); doc.removeEventListener('pointerdown', outside); doc.removeEventListener('focusin', outside); win.removeEventListener('resize', position); win.removeEventListener('scroll', position, true); win.visualViewport?.removeEventListener('resize', position); container.replaceChildren(); container.classList.remove('vibe-account'); },
  };
}
