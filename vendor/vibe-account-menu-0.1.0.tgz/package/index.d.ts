export interface AccountIdentity {
  rootDid: string;
  displayName: string;
  handle: string;
  avatarDataUri?: string | null;
}
export interface AccountMenuAction {
  id: string;
  label: string;
  href?: string;
  onSelect?: () => void | Promise<void>;
  icon?: 'bookmark' | 'settings' | 'external';
}
export interface AccountMenuOptions {
  appName: string;
  profile: AccountIdentity | null;
  locale?: 'sv' | 'en';
  busy?: boolean;
  compact?: boolean;
  placement?: 'above' | 'below';
  profileUrl?: string;
  remembered?: AccountIdentity[];
  actions?: AccountMenuAction[];
  notice?: string;
  onLogin: () => void | Promise<void>;
  onSwitchAccount: (loginHint?: string) => void | Promise<void>;
  onLogout: () => void | Promise<void>;
  onError?: (error: unknown) => void;
}
export interface AccountMenu {
  update(options: AccountMenuOptions): void;
  open(): void;
  destroy(): void;
}
export function accountMenuMarkup(options: AccountMenuOptions, id?: string): string;
export function createAccountMenu(container: HTMLElement, options: AccountMenuOptions): AccountMenu;
