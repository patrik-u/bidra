# @vibe/account-menu

A small framework-independent account menu. One DOM implementation handles
rendering, keyboard navigation, focus, viewport placement and safe text/image
presentation. Authentication and private app state stay with the host's SDK.

```ts
import { createAccountMenu } from '@vibe/account-menu'
import '@vibe/account-menu/style.css'

const menu = createAccountMenu(element, {
  appName: 'My app', locale: 'en', profile,
  remembered: sdk.rememberedAccounts(),
  profileUrl: sdk.nodeOrigin + '/profile',
  onLogin: () => login(),
  onSwitchAccount: hint => switchAccount(hint),
  onLogout: () => logoutOfThisApp(),
  onError: error => showError(error),
})
// On state changes, supply the full current configuration:
menu.update(nextOptions)
// Before removing the host:
menu.destroy()
```

React mounts the menu into an empty div in an effect, updates it on prop changes
and destroys it in cleanup. `Bidra/src/components/VibeAccountMenu.tsx` is the
thin adapter; no React dependency is required by this package. Avoid mounting
during SSR. Notes imports this same source directly; external consumers use the
packed npm artifact. Pack from this directory with `npm pack`.

`compact` hides the name beside the trigger (not inside the menu). `placement`
can prefer `above` for a sidebar; viewport space can override the preference.
`actions` accepts additional buttons or absolute HTTPS links. `notice` displays
a host-supplied status, such as a popup fallback with a matching custom action.
The profile link opens a separate tab. Optional `open()` reveals the menu after
an account-action error. A remembered identity is an authentication hint, never
a grant or proof of authentication. The host supplies only its origin-local list.

Host callbacks run synchronously in the click gesture, so they can open an
authorization popup before awaiting work. Promise errors go to `onError`.
`busy` disables account mutations; hosts must also serialize SDK changes and
clear private data when switching. The logout label explicitly names this app;
wire it to app logout, and expose broader Cloud logout as a separately labelled
custom action only when wanted.

Theme on the host container with CSS variables:
`--account-accent`, `--account-surface`, `--account-ink`, `--account-muted`,
`--account-border`, `--account-hover`, `--account-radius`, `--account-avatar-size`.
The component inherits its font. Swedish and English labels are included.
Avatar images accept bounded raster data URIs, not remote tracking URLs or SVG.
Initials are the fallback; the small DID-derived pattern is a recognition cue,
not cryptographic verification. The package reads/writes no browser storage,
sends no telemetry and makes no network requests itself.

The source lives in the Cloud pilot repository under `src/account-menu`.
Bidrakartan consumes a versioned archive committed in its `vendor` directory.
Update source, tests and docs here first, then pack a new version for consumers.
