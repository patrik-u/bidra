# @vibe/sdk

Framework-agnostic browser SDK for Vibe Cloud v0.1. It owns the reusable
authorization/session boundary; applications own their UI.

Hosts reserving `/callback` can pass `callbackPath: "/vibe-callback"` to
`VibeSessionClient`. Serve the app on that path too. For popup mode, pass the
same path to `completePopupCallback("/vibe-callback")`. The default remains
`/callback`; paths must be same-origin and have no query or fragment.

## Public v0.1 surface

```ts
import { VibeSessionClient, completePopupCallback } from "@vibe/sdk";

const vibe = new VibeSessionClient({ nodeOrigin: "https://node.example" });

if (!completePopupCallback()) {
  await vibe.completeRedirectCallback();
  await vibe.connectMany(["profile:read"]);
  const profile = await vibe.profile();
}
```

`VibeSessionClient` provides:

- `connect`, `connectMany`, and `resume` for PKCE authorization and rotating
  refresh sessions;
- `connectManyWithRedirect` as an explicit same-tab fallback when popups are
  unavailable;
- `switchAccount` with optional `loginHint` and redirect fallback;
- `completeRedirectCallback` and `completePopupCallback` for the return path;
- `profile`, `currentAccount`, and `rememberedAccounts`;
- `logout`, which removes local tokens first and asks the node to revoke the
  exact access/refresh tokens held by this app session;
- `logoutFromCloud`, which additionally opens the node's own CSRF-protected
  logout flow to revoke this app authorization and end the current node web
  session without weakening its HttpOnly/SameSite cookie;
- `discoverAppManifest` and `discoverNodeDescriptor`;
- `authorizedFetch` for a thin app-specific data client layered on top.

The remembered-account list contains only handle, display name, and root DID.
It is scoped to node + app origin in browser `localStorage`, is populated only
after that browser has successfully used an identity, and is never uploaded or
synced. It is convenience metadata, not identity linking.

Access tokens remain in `sessionStorage` (tab lifetime). Rotating refresh tokens
remain origin-scoped in `localStorage`. PKCE redirect state/verifier remains in
`sessionStorage`. The SDK never accepts, stores, or persists root keys, sealed-
vault keys, passwords, or authentication derivation material.

## Repository and release policy

This repository is the source of truth for the SDK. Vibe Cloud currently
consumes a reviewed `npm pack` artifact committed in its `vendor/` directory so
local and Fly builds are reproducible without assuming a public npm release or
making a private sibling path part of the build. Update that snapshot only after
SDK tests pass and record the SDK commit in the consumer documentation.

The package is `private: true` at `0.1.1`. Publishing to npm, changing visibility,
or adding React/Next wrappers requires a separate decision. A future React
package should be a thin consumer of this API, not a second auth implementation.

## Development

```powershell
npm install
npm test
npm run typecheck
npm run build
npm pack --pack-destination ..\vibe-cloud\vendor
```

Legacy design reference: `C:\Projects\attic\vibe\packages\vibe-sdk`,
`vibe-core`, and `vibe-react`. V0.1 keeps its good separation between protocol,
SDK, and UI, plus PKCE state checking and a thin framework adapter boundary. It
does not carry forward the hidden iframe/hub, multiple auth strategies, broad UI
package, debug credential logging, or server-side identity correlation.
