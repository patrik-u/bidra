export interface SupportOptions { cloudOrigin:string; appOrigin?:string; appName:string; accent?:string; locale?:"sv"|"en"; analyticsInfo?:boolean }
export function createSupportWidget(options:SupportOptions): {destroy():void;open():void};
export function recordEvent(cloudOrigin:string,event:"page_view"|"search"|"search_empty"|"detail_view"|"outbound_click",appOrigin?:string,object?:string):void;
