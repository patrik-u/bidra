# Vibe support widget

`createSupportWidget({cloudOrigin, appName, accent, locale})` mounts a themeable, dependency-free anonymous form using Shadow DOM. Call `destroy()` on unmount. Cloud must explicitly provision the app origin and an owner. No credentials belong in the widget.

Account-bound support opens `/support?app=<origin>` in Cloud and uses its session and CSRF protection. Existing app OAuth scopes do not grant access to support. Replies are read in Cloud; email delivery and live chat are not implemented.

`recordEvent(cloudOrigin, event)` sends a single anonymous event without cookies, referrer, query text, location or user identity. DNT/GPC opt out. Allowed events: page_view, search, search_empty, detail_view, outbound_click. These are indicative counters, not unique visitors or verified conversions. Apps choose when to emit them. Do not use it for private document identifiers or user attributes.

Support: 4000 characters/message, 50 replies/ticket, 2000 tickets/app, IP rate limits, 180-day inactivity retention. Counters: 400 days, 2-day duplicate receipt window. Operator access must be explicitly configured with `VIBE_OPERATOR_DIDS`; app administration does not imply operator access.
