export interface SupportOptions { cloudOrigin:string; appOrigin?:string; appName:string; accent?:string; locale?:"sv"|"en"; analyticsInfo?:boolean; context?:{route?:string;release?:string}; actionNames?:string[] }
export function createSupportWidget(options:SupportOptions): {destroy():void;open():void;trackAction(name:string):void;setContext(context:{route?:string;release?:string}):void;clearContext():void};
export function recordEvent(cloudOrigin:string,event:"page_view"|"search"|"search_empty"|"detail_view"|"outbound_click",appOrigin?:string,object?:string):void;
