export function imageAttachments(container:HTMLElement,options?:{locale?:string;capture?:boolean}):{values():string[];clear():void;destroy():void};
