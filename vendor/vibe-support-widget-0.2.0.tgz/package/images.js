/** Images stay local until the surrounding report is submitted. */
export function imageAttachments(container,{locale='sv',capture=true}={}) {
  const sv=locale==='sv',t=(a,b)=>sv?a:b;
  let images=[],pending=false,capturing=false,destroyed=false,generation=0;
  container.innerHTML=`<label>${t('Bifoga bilder','Attach images')}<input type="file" accept="image/png,image/jpeg,image/webp" multiple></label><p>${t('Klistra också in en bild här. Högst tre bilder.','You can also paste an image here. Up to three images.')}</p>${capture&&navigator.mediaDevices?.getDisplayMedia?`<button type="button" data-capture>${t('Ta skärmbild','Take screenshot')}</button>`:''}<div data-images></div><p role="status" data-image-status></p>`;
  const status=container.querySelector('[data-image-status]'),list=container.querySelector('[data-images]');
  function render(){list.replaceChildren();images.forEach((data,index)=>{const row=document.createElement('div'),img=document.createElement('img'),remove=document.createElement('button');img.src=data;img.alt=t('Bifogad bild','Attached image');img.style.cssText='max-width:100%;max-height:160px;display:block';remove.type='button';remove.textContent=t('Ta bort bild','Remove image');remove.onclick=()=>{images.splice(index,1);render();};row.append(img,remove);list.append(row);});}
  async function add(file){
    if(pending||destroyed)return;
    if(images.length>=3){status.textContent=t('Högst tre bilder.','Up to three images.');return;}
    if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>12*1024*1024){status.textContent=t('Välj PNG, JPEG eller WebP, högst 12 MiB.','Choose PNG, JPEG or WebP, up to 12 MiB.');return;}
    const seq=generation;pending=true;status.textContent=t('Bearbetar bild…','Processing image…');
    try{const bitmap=await createImageBitmap(file);if(bitmap.width*bitmap.height>12000000){bitmap.close();throw new Error();}const scale=Math.min(1,1800/Math.max(bitmap.width,bitmap.height));const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();const data=canvas.toDataURL('image/webp',.82);if(data.length>2700000)throw new Error();if(!destroyed&&seq===generation){images.push(data);render();status.textContent=t('Kontrollera bilden. Ta bort den om privat information syns.','Review the image. Remove it if private information is visible.');}}catch{if(seq===generation)status.textContent=t('Bilden kunde inte läsas eller är för stor.','Unable to read image, or it is too large.');}finally{if(seq===generation)pending=false;}
  }
  container.querySelector('input').onchange=async e=>{for(const file of e.target.files)await add(file);e.target.value='';};
  const paste=async e=>{const files=[...(e.clipboardData?.files??[])].filter(f=>f.type.startsWith('image/'));if(files.length){e.preventDefault();for(const file of files)await add(file);}};
  const pasteTarget=container.closest('form')??container;pasteTarget.addEventListener('paste',paste);
  container.querySelector('[data-capture]')?.addEventListener('click',async()=>{
    if(pending||capturing||images.length>=3)return;capturing=true;const seq=generation;let stream;
    try{stream=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false});const video=document.createElement('video');video.srcObject=stream;await video.play();const canvas=document.createElement('canvas');canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext('2d').drawImage(video,0,0);const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));stream.getTracks().forEach(track=>track.stop());stream=null;if(blob&&seq===generation&&!destroyed)await add(blob);}catch{status.textContent=t('Ingen skärmbild bifogades. Du kan välja eller klistra in en bild istället.','No screenshot attached. Choose or paste an image instead.');}finally{stream?.getTracks().forEach(track=>track.stop());if(seq===generation)capturing=false;}
  });
  return {values(){if(pending||capturing)throw new Error(t('Vänta tills bilden är klar.','Wait until image processing completes.'));return [...images];},clear(){generation++;pending=false;capturing=false;images=[];render();status.textContent='';},destroy(){generation++;destroyed=true;images=[];pasteTarget.removeEventListener('paste',paste);}};
}
