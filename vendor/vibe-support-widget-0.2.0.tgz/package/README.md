# Vibe support widget

`createSupportWidget({cloudOrigin, appName, accent, locale})` mounts a themeable, anonymous form using Shadow DOM. Call `destroy()` on unmount. Cloud must explicitly provision the app origin and an owner. No credentials belong in the widget.

Account-bound support opens `/support?app=<origin>` in Cloud and uses its session and CSRF protection. Existing app OAuth scopes do not grant access to support. Replies are read in Cloud; email delivery and live chat are not implemented.

`recordEvent(cloudOrigin, event)` sends a single anonymous event without cookies, referrer, query text, location or user identity. DNT/GPC opt out. Allowed events: page_view, search, search_empty, detail_view, outbound_click. These are indicative counters, not unique visitors or verified conversions. Apps choose when to emit them. Do not use it for private document identifiers or user attributes.

Support: 4000 characters/message, 50 replies/ticket, 2000 tickets/app, IP rate limits, 180-day inactivity retention. Counters: 400 days, 2-day duplicate receipt window. Operator access must be explicitly configured with `VIBE_OPERATOR_DIDS`; app administration does not imply operator access.

## Reports in 0.2.0

```js
const support = createSupportWidget({
  cloudOrigin: 'https://console.vibecloud.se', appName: 'My app',
  context: { route: 'explore', release: '1.2.0' },
  actionNames: ['detail.opened', 'search.submitted']
});
support.trackAction('detail.opened'); // no parameters or private values
support.setContext({ route: 'detail' }); // a declared route name, never a URL with IDs
// On account changes, including before login/logout:
support.clearContext();
support.setContext({ route: 'explore' });
```

The widget snapshots route/release, viewport dimensions, locale and up to 30 declared actions from the last five minutes when opened. The user can inspect and omit this context. Only names also allowed by the server policy are included. Nothing records form inputs, search text, URL parameters, note content or generic console logs. `clearContext()` closes the dialog, cancels pending work and drops drafts, images and history. Call it before switching identity.

Users may choose/paste up to three PNG/JPEG/WebP images. A screenshot button is offered where `getDisplayMedia` exists; every capture needs an explicit click and browser selection/permission. There is no invisible screen capture or image masking editor. Review previews before submission. Mobile browsers without capture support still accept images. The browser resizes images; Cloud decodes/re-encodes them as WebP, strips metadata and checks file/pixel limits. Uploads are private ticket attachments, not public Content assets.

Owners configure reports/images/context independently for everyone, signed-in accounts, app administrators, selected DIDs or nobody under their app's Access page. The embedded form is anonymous even if the host app is signed in; use the account link for verified reporting until a dedicated support OAuth contract is available. Default safe action names: `navigation.changed`, `filter.changed`, `detail.opened`, `search.submitted`. Apps must still opt in to each name in the SDK. The owner may replace this allowlist.

Default image storage quota: 20 MiB/app (owner may set 2–100 MiB), three images/report, 2 MiB/image on input, 12 megapixels. When full, remove old reports or adjust quota; text-only feedback still works. Attachments are included in individual ticket exports and deleted with the ticket/retention cleanup. These features do not start agent jobs or deploy code.
